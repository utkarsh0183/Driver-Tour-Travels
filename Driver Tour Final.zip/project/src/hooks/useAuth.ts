import { useState, useEffect, createContext, useContext } from 'react';
import { supabase } from '../lib/supabase';

interface AuthContextType {
  isAuthenticated: boolean;
  admin: any | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useAuthState = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [admin, setAdmin] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const adminData = localStorage.getItem('admin');
    if (adminData) {
      try {
        const parsedAdmin = JSON.parse(adminData);
        setAdmin(parsedAdmin);
        setIsAuthenticated(true);
      } catch (error) {
        localStorage.removeItem('admin');
      }
    }
    setLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      // For demo purposes, using simple validation
      // In production, you would hash passwords properly
      if (username === 'utkarsh' && password === 'Utkarsh@183') {
        const adminData = {
          id: '1',
          username: 'utkarsh',
          full_name: 'Utkarsh',
          role: 'owner',
          permissions: { all: true }
        };
        
        localStorage.setItem('admin', JSON.stringify(adminData));
        setAdmin(adminData);
        setIsAuthenticated(true);
        return true;
      }

      // Check against database for other admins
      const { data: admins, error } = await supabase
        .from('admins')
        .select('*')
        .eq('username', username)
        .eq('is_active', true);

      if (error || !admins || admins.length === 0) {
        return false;
      }

      // In a real app, you'd verify the hashed password
      const adminData = admins[0];
      localStorage.setItem('admin', JSON.stringify(adminData));
      setAdmin(adminData);
      setIsAuthenticated(true);
      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('admin');
    setAdmin(null);
    setIsAuthenticated(false);
  };

  return {
    isAuthenticated,
    admin,
    loading,
    login,
    logout
  };
};

export { AuthContext };