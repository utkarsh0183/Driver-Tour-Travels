import React, { useState, useEffect } from 'react';
import { MapPin, Phone, User } from 'lucide-react';
import Header from '../components/Layout/Header';
import Footer from '../components/Layout/Footer';
import Slideshow from '../components/Homepage/Slideshow';
import BookingForm from '../components/Homepage/BookingForm';
import BookingSearch from '../components/Homepage/BookingSearch';
import { supabase } from '../lib/supabase';

interface HomepageSettings {
  site_title: string;
  homepage_description: string;
  director_name: string;
  office_address: string;
}

const Homepage: React.FC = () => {
  const [settings, setSettings] = useState<HomepageSettings>({
    site_title: 'Driver Tour & Travels',
    homepage_description: 'Your trusted partner for comfortable and reliable transportation services.',
    director_name: 'Utkarsh',
    office_address: '123 Business District, City Center, State - 12345'
  });
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('settings')
        .select('*');

      if (error) {
        console.error('Error fetching settings:', error);
        // Continue with default settings if database fetch fails
      } else if (data) {
        const settingsMap: Record<string, string> = {};
        data.forEach(setting => {
          settingsMap[setting.key] = setting.value;
        });

        setSettings({
          site_title: settingsMap.site_title || 'Driver Tour & Travels',
          homepage_description: settingsMap.homepage_description || 'Your trusted partner for comfortable and reliable transportation services.',
          director_name: settingsMap.director_name || 'Utkarsh',
          office_address: settingsMap.office_address || '123 Business District, City Center, State - 12345'
        });
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
      // Continue with default settings
    } finally {
      setLoading(false);
    }
  };

  const handleBookingSuccess = () => {
    setShowConfirmation(true);
  };

  const ConfirmationModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-8 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
          </svg>
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-4">Booking Submitted!</h3>
        <p className="text-gray-600 mb-6">
          Thanks for your interest in {settings.site_title}. You will receive a call for more details within an hour.
        </p>
        <button
          onClick={() => setShowConfirmation(false)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      <Header title={settings.site_title} />
      
      <main className="container mx-auto px-4 py-12 space-y-16">
        {/* Hero Section with Slideshow */}
        <section className="space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 leading-tight">
              Premium Transportation Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              {settings.homepage_description}
            </p>
          </div>
          
          <Slideshow />
        </section>

        {/* Main Content Grid */}
        <section className="grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2 space-y-8">
            <BookingForm onSuccess={handleBookingSuccess} />
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Booking Search */}
            <BookingSearch />

            {/* Contact Information */}
            <div className="bg-white rounded-2xl shadow-2xl p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">Contact Information</h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <User className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-800">Director</p>
                    <p className="text-gray-600">{settings.director_name}</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-800">Office Address</p>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {settings.office_address}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      
      {showConfirmation && <ConfirmationModal />}
    </div>
  );
};

export default Homepage;