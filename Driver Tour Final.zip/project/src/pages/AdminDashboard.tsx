import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from '../components/Admin/Sidebar';
import Dashboard from '../components/Admin/Dashboard';
import BookingManagement from '../components/Admin/BookingManagement';
import HomepageManagement from '../components/Admin/HomepageManagement';
import Header from '../components/Layout/Header';
import { useAuth } from '../hooks/useAuth';

const AdminDashboard: React.FC = () => {
  const { logout, admin } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isAdmin={true} onLogout={logout} title="Admin Dashboard" />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/bookings" element={<BookingManagement />} />
            <Route path="/homepage" element={<HomepageManagement />} />
            <Route path="/admins" element={<div className="text-center py-12"><h2 className="text-2xl font-bold text-gray-700">Admin Management</h2><p className="text-gray-500 mt-4">Feature coming soon...</p></div>} />
            <Route path="/reports" element={<div className="text-center py-12"><h2 className="text-2xl font-bold text-gray-700">Reports</h2><p className="text-gray-500 mt-4">Feature coming soon...</p></div>} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;