import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables');
  console.log('VITE_SUPABASE_URL:', supabaseUrl);
  console.log('VITE_SUPABASE_ANON_KEY:', supabaseAnonKey ? 'Present' : 'Missing');
}

export const supabase = createClient(
  supabaseUrl || 'https://fkzmhxssdjmeztbutkxr.supabase.co',
  supabaseAnonKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZrem1oeHNzZGptZXp0YnV0a3hyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAyNDAwNjAsImV4cCI6MjA2NTgxNjA2MH0.D1_2f069SfwhGKy1r-jE68A5t2oiNEO2bO8TTffnj90'
);

// Types
export interface Settings {
  id: string;
  key: string;
  value: string;
  created_at: string;
  updated_at: string;
}

export interface Booking {
  id: string;
  name: string;
  mobile: string;
  pickup_location: string;
  destination: string;
  booking_date: string;
  booking_time: string;
  service_type: 'driver' | 'car_driver';
  remarks: string;
  status: 'pending' | 'approved' | 'declined' | 'completed';
  created_at: string;
  updated_at: string;
  payments?: Payment[];
}

export interface SlideshowImage {
  id: string;
  image_url: string;
  alt_text: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
}

export interface Admin {
  id: string;
  username: string;
  full_name: string;
  role: 'owner' | 'admin' | 'manager';
  permissions: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  booking_id: string;
  amount: number;
  payment_method: 'cash' | 'bank';
  payment_date: string;
  notes: string;
  created_at: string;
}