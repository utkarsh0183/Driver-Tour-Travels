import React from 'react';
import { Link } from 'react-router-dom';
import { Car, Settings, LogOut } from 'lucide-react';

interface HeaderProps {
  isAdmin?: boolean;
  onLogout?: () => void;
  title?: string;
}

const Header: React.FC<HeaderProps> = ({ isAdmin = false, onLogout, title = "Driver Tour & Travels" }) => {
  return (
    <header className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white shadow-2xl">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
            <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 p-3 rounded-xl shadow-lg">
              <Car className="h-8 w-8 text-blue-900" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-yellow-300 to-yellow-100 bg-clip-text text-transparent">
                {title}
              </h1>
              <p className="text-sm text-blue-200">Your Premium Travel Partner</p>
            </div>
          </Link>

          <div className="flex items-center space-x-4">
            {!isAdmin ? (
              <Link
                to="/admin"
                className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-blue-900 px-6 py-2 rounded-lg font-semibold hover:from-yellow-400 hover:to-yellow-500 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                <Settings className="inline-block w-4 h-4 mr-2" />
                Admin
              </Link>
            ) : (
              <button
                onClick={onLogout}
                className="bg-red-600 hover:bg-red-700 px-6 py-2 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                <LogOut className="inline-block w-4 h-4 mr-2" />
                Logout
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;