import React, { useState, useEffect } from 'react';
import { Save, Upload, Trash2, Plus, Edit3 } from 'lucide-react';
import { supabase, Settings, SlideshowImage } from '../../lib/supabase';
import toast from 'react-hot-toast';

const HomepageManagement: React.FC = () => {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [slideshowImages, setSlideshowImages] = useState<SlideshowImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newImageAlt, setNewImageAlt] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch settings
      const { data: settingsData, error: settingsError } = await supabase
        .from('settings')
        .select('*');

      if (settingsError) throw settingsError;

      const settingsMap: Record<string, string> = {};
      settingsData?.forEach(setting => {
        settingsMap[setting.key] = setting.value;
      });
      setSettings(settingsMap);

      // Fetch slideshow images
      const { data: imagesData, error: imagesError } = await supabase
        .from('slideshow_images')
        .select('*')
        .order('display_order');

      if (imagesError) throw imagesError;
      setSlideshowImages(imagesData || []);

    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to fetch homepage data');
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = async (key: string, value: string) => {
    try {
      const { error } = await supabase
        .from('settings')
        .upsert([{ key, value, updated_at: new Date().toISOString() }]);

      if (error) throw error;
      
      setSettings(prev => ({ ...prev, [key]: value }));
      toast.success('Setting updated successfully');
    } catch (error) {
      console.error('Error updating setting:', error);
      toast.error('Failed to update setting');
    }
  };

  const addSlideshowImage = async () => {
    if (!newImageUrl.trim()) {
      toast.error('Please enter an image URL');
      return;
    }

    try {
      const maxOrder = Math.max(...slideshowImages.map(img => img.display_order), 0);
      
      const { data, error } = await supabase
        .from('slideshow_images')
        .insert([{
          image_url: newImageUrl.trim(),
          alt_text: newImageAlt.trim() || 'Slideshow image',
          display_order: maxOrder + 1
        }])
        .select();

      if (error) throw error;

      setSlideshowImages(prev => [...prev, data[0]]);
      setNewImageUrl('');
      setNewImageAlt('');
      toast.success('Image added successfully');
    } catch (error) {
      console.error('Error adding image:', error);
      toast.error('Failed to add image');
    }
  };

  const updateImageOrder = async (imageId: string, newOrder: number) => {
    try {
      const { error } = await supabase
        .from('slideshow_images')
        .update({ display_order: newOrder })
        .eq('id', imageId);

      if (error) throw error;

      setSlideshowImages(prev =>
        prev.map(img => img.id === imageId ? { ...img, display_order: newOrder } : img)
          .sort((a, b) => a.display_order - b.display_order)
      );
      
      toast.success('Image order updated');
    } catch (error) {
      console.error('Error updating image order:', error);
      toast.error('Failed to update image order');
    }
  };

  const toggleImageStatus = async (imageId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('slideshow_images')
        .update({ is_active: isActive })
        .eq('id', imageId);

      if (error) throw error;

      setSlideshowImages(prev =>
        prev.map(img => img.id === imageId ? { ...img, is_active: isActive } : img)
      );
      
      toast.success(`Image ${isActive ? 'activated' : 'deactivated'}`);
    } catch (error) {
      console.error('Error updating image status:', error);
      toast.error('Failed to update image status');
    }
  };

  const deleteImage = async (imageId: string) => {
    if (!confirm('Are you sure you want to delete this image?')) return;

    try {
      const { error } = await supabase
        .from('slideshow_images')
        .delete()
        .eq('id', imageId);

      if (error) throw error;

      setSlideshowImages(prev => prev.filter(img => img.id !== imageId));
      toast.success('Image deleted successfully');
    } catch (error) {
      console.error('Error deleting image:', error);
      toast.error('Failed to delete image');
    }
  };

  const handleSettingChange = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const saveAllSettings = async () => {
    setSaving(true);
    try {
      const updates = Object.entries(settings).map(([key, value]) => ({
        key,
        value,
        updated_at: new Date().toISOString()
      }));

      const { error } = await supabase
        .from('settings')
        .upsert(updates);

      if (error) throw error;
      
      toast.success('All settings saved successfully');
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Homepage Management</h1>
        <button
          onClick={saveAllSettings}
          disabled={saving}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors disabled:opacity-50 flex items-center space-x-2"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save All Changes'}</span>
        </button>
      </div>

      {/* Site Settings */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <Edit3 className="w-5 h-5 mr-2" />
          Site Settings
        </h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Site Title
            </label>
            <input
              type="text"
              value={settings.site_title || ''}
              onChange={(e) => handleSettingChange('site_title', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Driver Tour & Travels"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Site Logo URL
            </label>
            <input
              type="url"
              value={settings.site_logo || ''}
              onChange={(e) => handleSettingChange('site_logo', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="https://example.com/logo.png"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Homepage Description
            </label>
            <textarea
              value={settings.homepage_description || ''}
              onChange={(e) => handleSettingChange('homepage_description', e.target.value)}
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              placeholder="Describe your services..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Director Name
            </label>
            <input
              type="text"
              value={settings.director_name || ''}
              onChange={(e) => handleSettingChange('director_name', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Director Name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Office Address
            </label>
            <textarea
              value={settings.office_address || ''}
              onChange={(e) => handleSettingChange('office_address', e.target.value)}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              placeholder="Office Address"
            />
          </div>
        </div>
      </div>

      {/* Slideshow Management */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <Upload className="w-5 h-5 mr-2" />
          Slideshow Images
        </h2>

        {/* Add New Image */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Add New Image</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <input
                type="url"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                placeholder="Enter image URL (e.g., https://images.pexels.com/...)"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <input
                type="text"
                value={newImageAlt}
                onChange={(e) => setNewImageAlt(e.target.value)}
                placeholder="Alt text (optional)"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <button
            onClick={addSlideshowImage}
            className="mt-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Image</span>
          </button>
        </div>

        {/* Existing Images */}
        <div className="space-y-4">
          {slideshowImages.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No slideshow images found</p>
          ) : (
            slideshowImages.map((image, index) => (
              <div key={image.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-4">
                  <div className="flex-shrink-0">
                    <img
                      src={image.image_url}
                      alt={image.alt_text}
                      className="w-32 h-20 object-cover rounded-lg"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = 'https://via.placeholder.com/150x100/e5e7eb/9ca3af?text=Image+Not+Found';
                      }}
                    />
                  </div>
                  
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{image.alt_text}</p>
                    <p className="text-sm text-gray-500 break-all">{image.image_url}</p>
                  </div>

                  <div className="flex items-center space-x-2">
                    <select
                      value={image.display_order}
                      onChange={(e) => updateImageOrder(image.id, parseInt(e.target.value))}
                      className="border border-gray-300 rounded px-2 py-1 text-sm"
                    >
                      {Array.from({ length: slideshowImages.length }, (_, i) => (
                        <option key={i + 1} value={i + 1}>
                          Position {i + 1}
                        </option>
                      ))}
                    </select>

                    <button
                      onClick={() => toggleImageStatus(image.id, !image.is_active)}
                      className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                        image.is_active
                          ? 'bg-green-100 text-green-800 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                    >
                      {image.is_active ? 'Active' : 'Inactive'}
                    </button>

                    <button
                      onClick={() => deleteImage(image.id)}
                      className="text-red-600 hover:text-red-800 p-1 rounded transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default HomepageManagement;