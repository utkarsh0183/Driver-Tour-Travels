import React, { useState } from 'react';
import { Search, Phone, Eye, Calendar, MapPin, Clock, User, FileText } from 'lucide-react';
import { supabase, Booking } from '../../lib/supabase';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

const BookingSearch: React.FC = () => {
  const [mobile, setMobile] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const searchBookings = async () => {
    if (!mobile.trim()) {
      toast.error('Please enter a mobile number');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          payments (
            amount,
            payment_method,
            payment_date
          )
        `)
        .eq('mobile', mobile.trim())
        .order('created_at', { ascending: false });

      if (error) throw error;

      setBookings(data || []);
      setSearched(true);
      
      if (data && data.length === 0) {
        toast.info('No bookings found for this mobile number');
      }
    } catch (error) {
      console.error('Error searching bookings:', error);
      toast.error('Failed to search bookings');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'approved':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'declined':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTotalPaid = (payments: any[]) => {
    if (!payments || payments.length === 0) return 0;
    return payments.reduce((total, payment) => total + parseFloat(payment.amount), 0);
  };

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-6">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Track Your Bookings</h3>
        <p className="text-gray-600">Enter your mobile number to view all your bookings</p>
      </div>

      {/* Search Form */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="tel"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            placeholder="Enter your mobile number"
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            onKeyPress={(e) => e.key === 'Enter' && searchBookings()}
          />
        </div>
        <button
          onClick={searchBookings}
          disabled={loading}
          className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {loading ? (
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Searching...
            </div>
          ) : (
            <>
              <Search className="inline-block w-4 h-4 mr-2" />
              Search
            </>
          )}
        </button>
      </div>

      {/* Results */}
      {searched && (
        <div className="space-y-4">
          {bookings.length === 0 ? (
            <div className="text-center py-8">
              <Eye className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No bookings found</p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-semibold text-gray-800">
                  Found {bookings.length} booking{bookings.length !== 1 ? 's' : ''}
                </h4>
              </div>
              
              {bookings.map((booking) => (
                <div key={booking.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <User className="w-5 h-5 text-gray-400" />
                      <span className="font-semibold text-gray-800">{booking.name}</span>
                    </div>
                    <div className="flex items-center mt-2 sm:mt-0">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(booking.status)}`}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center space-x-3">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">From: {booking.pickup_location}</p>
                        <p className="text-sm text-gray-600">To: {booking.destination}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">
                          Date: {format(new Date(booking.booking_date), 'MMM dd, yyyy')}
                        </p>
                        <p className="text-sm text-gray-600">Time: {booking.booking_time}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <span className="text-sm bg-gray-100 px-3 py-1 rounded">
                        {booking.service_type === 'driver' ? 'Driver Only' : 'Car + Driver'}
                      </span>
                      
                      {booking.payments && booking.payments.length > 0 && (
                        <span className="text-sm bg-green-100 text-green-800 px-3 py-1 rounded">
                          Paid: ₹{getTotalPaid(booking.payments).toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                    
                    <p className="text-xs text-gray-500">
                      Booked: {format(new Date(booking.created_at), 'MMM dd, yyyy')}
                    </p>
                  </div>

                  {booking.remarks && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="flex items-start space-x-2">
                        <FileText className="w-4 h-4 text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-sm text-gray-600 font-medium">Remarks:</p>
                          <p className="text-sm text-gray-600">{booking.remarks}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default BookingSearch;