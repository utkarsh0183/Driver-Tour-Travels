import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Phone, FileText, Car, UserCheck } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';

interface BookingFormData {
  name: string;
  mobile: string;
  pickup_location: string;
  destination: string;
  booking_date: string;
  booking_time: string;
  service_type: 'driver' | 'car_driver';
  remarks: string;
}

interface BookingFormProps {
  onSuccess: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({ onSuccess }) => {
  const [formData, setFormData] = useState<BookingFormData>({
    name: '',
    mobile: '',
    pickup_location: '',
    destination: '',
    booking_date: '',
    booking_time: '',
    service_type: 'driver',
    remarks: ''
  });
  const [loading, setLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleServiceTypeChange = (type: 'driver' | 'car_driver') => {
    setFormData(prev => ({
      ...prev,
      service_type: type
    }));
  };

  const validateForm = (): boolean => {
    if (!formData.name.trim()) {
      toast.error('Please enter your name');
      return false;
    }
    if (!formData.mobile.trim() || formData.mobile.length < 10) {
      toast.error('Please enter a valid mobile number');
      return false;
    }
    if (!formData.pickup_location.trim()) {
      toast.error('Please enter pickup location');
      return false;
    }
    if (!formData.destination.trim()) {
      toast.error('Please enter destination');
      return false;
    }
    if (!formData.booking_date) {
      toast.error('Please select booking date');
      return false;
    }
    if (!formData.booking_time) {
      toast.error('Please select booking time');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    
    try {
      const { error } = await supabase
        .from('bookings')
        .insert([formData]);

      if (error) throw error;

      toast.success('Booking submitted successfully!');
      setFormData({
        name: '',
        mobile: '',
        pickup_location: '',
        destination: '',
        booking_date: '',
        booking_time: '',
        service_type: 'driver',
        remarks: ''
      });
      onSuccess();
    } catch (error) {
      console.error('Error submitting booking:', error);
      toast.error('Failed to submit booking. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Book Your Ride</h2>
        <p className="text-gray-600">Fill in the details below to make your booking</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Name */}
          <div className="relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Full Name *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Enter your full name"
                required
              />
            </div>
          </div>

          {/* Mobile */}
          <div className="relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Mobile Number *
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="tel"
                name="mobile"
                value={formData.mobile}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Enter your mobile number"
                required
              />
            </div>
          </div>

          {/* Pickup Location */}
          <div className="relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Pickup Location *
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="pickup_location"
                value={formData.pickup_location}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Enter pickup location"
                required
              />
            </div>
          </div>

          {/* Destination */}
          <div className="relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Destination *
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="destination"
                value={formData.destination}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Enter destination"
                required
              />
            </div>
          </div>

          {/* Date */}
          <div className="relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Booking Date *
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="date"
                name="booking_date"
                value={formData.booking_date}
                onChange={handleInputChange}
                min={new Date().toISOString().split('T')[0]}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          {/* Time */}
          <div className="relative">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Booking Time *
            </label>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="time"
                name="booking_time"
                value={formData.booking_time}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>
          </div>
        </div>

        {/* Service Type */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-4">
            Service Type *
          </label>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => handleServiceTypeChange('driver')}
              className={`p-4 rounded-lg border-2 transition-all ${
                formData.service_type === 'driver'
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
            >
              <UserCheck className="w-8 h-8 mx-auto mb-2" />
              <span className="font-semibold">Book Driver</span>
            </button>
            <button
              type="button"
              onClick={() => handleServiceTypeChange('car_driver')}
              className={`p-4 rounded-lg border-2 transition-all ${
                formData.service_type === 'car_driver'
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
            >
              <Car className="w-8 h-8 mx-auto mb-2" />
              <span className="font-semibold">Book Car + Driver</span>
            </button>
          </div>
        </div>

        {/* Remarks */}
        <div className="relative">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Remarks (Optional)
          </label>
          <div className="relative">
            <FileText className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
            <textarea
              name="remarks"
              value={formData.remarks}
              onChange={handleInputChange}
              rows={4}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
              placeholder="Any special requirements or additional information..."
            />
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-4 px-6 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {loading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Submitting...
            </div>
          ) : (
            'Submit Booking'
          )}
        </button>
      </form>
    </div>
  );
};

export default BookingForm;